export const fontSizes = {
    small: 12,
    regular: 14,
    medium: 16,
    upperMedium: 18,
    large: 20,
    upperLarge: 22,
    extraLarge: 24,
};