const fontStyles = {
  regular: 'OpenSans-Regular',
  italic: 'OpenSans-Italic',
  bold: 'OpenSans-Bold',
  boldItalic: 'OpenSans-BoldItalic',
};

export { fontStyles };
